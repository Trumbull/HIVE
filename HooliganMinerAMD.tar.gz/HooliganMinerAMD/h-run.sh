#!/usr/bin/env bash

cd `dirname $0`

[ -t 1 ] && . colors

. h-manifest.conf
. /hive-config/rig.conf
. /hive-config/wallet.conf

[[ -z $WORKER_NAME ]] && echo -e "${RED}No WORKER_NAME set${NOCOLOR}" && exit 1
[[ -z $DWAL ]] && echo -e "${RED}No DWAL set${NOCOLOR}" && exit 1

#echo "================================"
#echo $CUSTOM_MINER
#echo $CUSTOM_LOG_BASENAME
#echo $CUSTOM_CONFIG_FILENAME
#echo "================================"
#echo $CUSTOM_USER_CONFIG
#echo $WORKER_NAME
#echo $EWAL
#echo "================================"

[[ -z $CUSTOM_LOG_BASENAME ]] && echo -e "${RED}No CUSTOM_LOG_BASENAME is set${NOCOLOR}" && exit 1
[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && exit 1
[[ ! -f $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}Custom config ${YELLOW}$CUSTOM_CONFIG_FILENAME${RED} is not found${NOCOLOR}" && exit 1
CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR
[[ -d $CUSTOM_LOG_BASEDIR ]] && [[ ! -f $CUSTOM_LOG_BASEDIR/$CUSTOM_NAME ]] && cp -f /hive/custom/$CUSTOM_NAME/HooliganMiner $CUSTOM_LOG_BASEDIR/$CUSTOM_NAME && cp -f /hive/custom/$CUSTOM_NAME/HooliganMiner.conf $CUSTOM_LOG_BASEDIR/$CUSTOM_NAME.conf

echo "Hooligan miner"
echo "(c) RUKOZHOPOFF PRODUCTION"
echo "Starting miner..."

set +x
#./HooliganMiner wallet_address=$CUSTOM_TEMPLATE miner_name=$WORKER_NAME statfile=$CUSTOM_LOG_BASENAME.log
#./HooliganMiner $(< /hive/custom/$CUSTOM_NAME/$CUSTOM_NAME.conf)
./HooliganMiner $(< /hive/custom/$CUSTOM_NAME/$CUSTOM_NAME.conf) | tee $CUSTOM_LOG_BASENAME.log
